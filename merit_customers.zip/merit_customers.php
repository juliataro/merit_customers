<?php
/**
 * Merit API Plugin
 *
 * @package     merit_customers
 * @author      Julia Taro
 * @copyright   2021 Julia Taro
 * @license     GPL-2.0-or-later
 * @wordpress-plugin
 * Plugin Name: merit_customers
 * Description: This plugin prints "Merit Api Plugin" inside an admin page.
 * Version:     1.0.0
 * Author:      Julia Taro
 * Author URI:  https://http://yuliataro.ikt.khk.ee
 * Text Domain: merit_customers
 */

// Get list code example
function signURL($id, $key, $timestamp, $json){
 $signable = $id.$timestamp.$json;
 // NOTICE:  bool $raw_output = TRUE
 $rawSig = hash_hmac('sha256', $signable, $key, true);
 // key-hashed message authentication code

 $base64Sig = base64_encode($rawSig); // encoding JSON binary data prevent modificcation through tronsporting
 return $base64Sig;
}

// Search for customer  to Merit API
function findCustomer($stuff, $endpoint) {
  $ch = curl_init();

    // random test company
    $APIID = "eb854b11-db9c-495f-a108-ce5fbcb59ccb";
    $APIKEY = "883GM0TSFxJqg/OANR5fgKi5U3FIHeEgICt4M7ZsAds=";
    $TIMESTAMP = date("YmdHis");

    $signature = signURL($APIID,$APIKEY, $TIMESTAMP,  json_encode($stuff));
    curl_setopt($ch, CURLOPT_URL, "https://aktiva.merit.ee/api/v1/".$endpoint."?ApiId=".$APIID."&timestamp=".$TIMESTAMP."&signature=".$signature);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($stuff));
    curl_exec($ch);
	if(curl_getinfo($ch, CURLINFO_RESPONSE_CODE) != 200) {
	print("ERROR ".curl_getinfo($ch, CURLINFO_RESPONSE_CODE)."\r\n");
	print_r(curl_getinfo($ch));
 }
 curl_close($ch); // closing connection
 }
    $findClient = array("Name" => "Julia Taro", "Email"=> "julia.taro@khk.ee");

    findCustomer($findClient, "getcustomers");

    // Plugin shortcode
    add_shortcode('check','findCustomer');



// Search for customer in Merit API
function sendCustomer($stuff, $endpoint) {
    $ch = curl_init();

    // random test company
    $APIID = "eb854b11-db9c-495f-a108-ce5fbcb59ccb";
    $APIKEY = "883GM0TSFxJqg/OANR5fgKi5U3FIHeEgICt4M7ZsAds=";
    $TIMESTAMP = date("YmdHis");

    $signature = signURL($APIID,$APIKEY, $TIMESTAMP,  json_encode($stuff));
    curl_setopt($ch, CURLOPT_URL, "https://aktiva.merit.ee/api/v2/".$endpoint."?ApiId=".$APIID."&timestamp=".$TIMESTAMP."&signature=".$signature);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($stuff));
    curl_exec($ch);
    if(curl_getinfo($ch, CURLINFO_RESPONSE_CODE) != 200) {
        print("ERROR ".curl_getinfo($ch, CURLINFO_RESPONSE_CODE)."\r\n");
        print_r(curl_getinfo($ch));
    }
    curl_close($ch); // closing connection
}


$sendClient = [
    "Customer" => [
        "Name" => "Julia Taro",
        "RegNo" => "1232233234",
        "NotTDCustomer" => "false",
        "VatRegNo" => "ATU99999999",
        "CurrencyCode" => "EUR",
        "PaymentDeadLine" => "7",
        "OverDueCharge" => "0",
        "RefNoBase" => "0",
        "Address" => "Linnamae tee 3",
        "CountryCode" => "EE",
        "County" => "Polvamaa",
        "City" => "Polva",
        "PostalCode" => "EE80034",
        "PhoneNo" => "55555555",
        "PhoneNo2" => "0",
        "HomePage" => "google.com",
        "Email"=> "julia.taro@khk.ee",
        "SalesInvLang" => "ET",
        "Contact" => "contact",
        "GLNCode" => "0",
        "PartyCode" => "0",
        "EInvOperator" => "2",
        "EInvPaymId" => "",
        "BankAccount" => "",
        "Dimensions" => [
            "DimId" => "11",
            "DimValueId" => "4c8b2ec0-af0f-46fb-8d2b-427165c1effc",
            "DimCode" => "Miski"],
        "DimCode" => "1"]];

sendCustomer($sendClient, "sendcustomer");

// Plugin shortcode
add_shortcode('send','sendCustomer');

// Plugin shortcode


